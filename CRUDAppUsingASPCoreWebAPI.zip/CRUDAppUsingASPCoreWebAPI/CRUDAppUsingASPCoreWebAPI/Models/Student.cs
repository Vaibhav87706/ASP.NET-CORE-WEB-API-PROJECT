﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAppUsingASPCoreWebAPI.Models
{



    public class Student
    {
        public int id { get; set; }

        [Required]
        public string name { get; set; }

        [Required]
        public string designation { get; set; }

        [Required]
        public string address { get; set; }

        [Required]
        public DateTime recordCreatedOn { get; set; }
    }


}
