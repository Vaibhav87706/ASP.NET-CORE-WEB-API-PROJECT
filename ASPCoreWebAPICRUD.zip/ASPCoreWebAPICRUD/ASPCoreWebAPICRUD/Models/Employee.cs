﻿using System;
using System.Collections.Generic;

namespace ASPCoreWebAPICRUD.Models
{
    public partial class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string Designation { get; set; } = null!;
        public string Address { get; set; } = null!;
        public DateTime? RecordCreatedOn { get; set; }
    }
}
