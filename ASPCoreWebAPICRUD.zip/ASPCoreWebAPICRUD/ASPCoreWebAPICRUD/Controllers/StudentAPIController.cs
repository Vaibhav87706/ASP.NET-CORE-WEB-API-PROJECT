﻿using ASPCoreWebAPICRUD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ASPCoreWebAPICRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAPIController : ControllerBase
    {
        private readonly EmployeeDatabaseContext context;

        public StudentAPIController(EmployeeDatabaseContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<Employee>>> GetStudents()
        {
            var data = await context.Employees.ToListAsync();
            return Ok(data);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetStudentById(int id)
        {
            var employee = await context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound(); 
            }
            return employee;
        }

        [HttpPost]
        public async Task<ActionResult<Employee>> CreateStudent(Employee emp)
        {
            await context.Employees.AddAsync(emp);
            await context.SaveChangesAsync();
            return Ok();
        }


        [HttpPut("{id}")]
        public async Task<ActionResult<Employee>> UpdateStudent(int id ,Employee emp)
        {
            if(id != emp.Id)
            {
                return BadRequest();
            }
            context.Entry(emp).State = EntityState.Modified;
            await context.SaveChangesAsync();
            return Ok(emp);
        }



        [HttpDelete("{id}")]
        public async Task<ActionResult<Employee>> DeleteStudent(int id)
        {
            var emp = await context.Employees.FindAsync(id);
            if(emp == null)
            {
                return NotFound(id);
            }
            context.Employees.Remove(emp);
            await context.SaveChangesAsync();
            return Ok();

        }








    }
}
